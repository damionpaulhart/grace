<?php
 require 'header.php';
?>
<!-- ================================================== -->
<h1>Confirmation Page</h1>
<p>&nbsp;</p>
    <div class="alert alert-success">
    <!--<a class="close" data-dismiss="alert">×</a>-->
    <strong>Saved.</strong> The form is now in the database.
    </div>
<p><a href="index.php">Return Home</a></p>

<!-- ================================================== -->
<?php
 require 'footer.php';
?>