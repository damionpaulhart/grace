<!-- ================================================== -->
      <footer>
        <p><h6>GRACE TRAILER SERVICE 615 PETRO COVE WEST MEMPHIS, AR 72301 870-732-0404</h6></p>
      </footer>

    </div><!--/.container-->


    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.21/jquery-ui.min.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    
<script>
jQuery(document).ready(function() {
	// if the form is formViewer, disable everything
	$('.formViewer').find(':input:not(:disabled)').prop('disabled',true).css('background-color','#eeeeee');
	$('#dateInspect').datepicker();
	$('#dateInspector').datepicker();
});
</script>
  </body>
</html>
