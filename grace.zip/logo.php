<!-- logo.php  ================================================== -->
<?php
	if($formViewer==1) { 
		echo '<div id="tools">';
		//if ($user == 'admin') {
		//	echo '<a id="deletelink" href="form-delete.php?form=' . $form_name . '&entry=' .$entryID . '">Delete</a> | ';
		//};
		echo '<a id="printlink" href="#" onclick="window.print(); return false;">Print</a> ';
		echo '</div>';
	}
?>

<div id="border">

<table width="768px" border="0" cellpadding="8">
  <tr>
    <td colspan="2"><img src="grace_logo.png" width="305" height="162"></td>
    <td valign="top"><p>GRACE TRAILER SERVICE</p>
      <p>615 PETRO COVE</p>
      <p>WEST MEMPHIS, AR 72301</p>
      <p>PHONE: 870-732-0404</p>
      <p><a href="../../www.gracetrailer.com">www.gracetrailer.com</a></p></td>
    </tr>
    </table>
<!-- // logo.php ================================================== -->